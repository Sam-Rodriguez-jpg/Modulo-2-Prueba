# Explicación Modulo 2 - Prueba de desempeño
### Por: Samuel Rodríguez Quintero

## HTML
Con ! + Tab, Cree la estructura basica HTML donde puse el contenido de mi portafolio, en 'head' exporte las fuentes y el CSS.

### Body
En 'body' empece parte por parte, lo dividi en la informacion sobre mi, proyectos y contacto, ademas en el 'header' hice un mini menu para dirigirme a una seccion en especifico, en este caso el mini menu lo hice dentro de un 'nav' y puse una lista para lo botones.

### Main & Sections
La base de todo el contenido esta en 'main' donde le asigne una clase y ahí es donde esta mi contenedor principal, aqui lo fui dividiendo en micro secciones con la etiqueta 'section' y agregandole una clase para posteriormente en CSS seleccionarlo.

### Divs
En los divs pongo el contenido de cada seccion, aqui van los proyectos uno por uno, mi informacion, y mis redes y github, cada uno con su id y class para luego selecionarlos.

### Footer
Al final de mi pagina esta el footer donde dejo el copyright y un botn para volver al inicio de mi pagina.


## CSS
Luego de exportar el archivo a mi HTML, ya con las ids y las classes voy aplicando estilo por estilo, en predeterminado reseteo el padding y el margin y cada que necesite moverlo, lo hago elemento por elemento.

### Responsive
Por ultimo con @media adapto mi pagina para diferentes tipos de pantallas, aqui tengo que volver a selecionar el contenido que quiero que cuando este en un tamaño especifico, el contenido tambien cambie.

