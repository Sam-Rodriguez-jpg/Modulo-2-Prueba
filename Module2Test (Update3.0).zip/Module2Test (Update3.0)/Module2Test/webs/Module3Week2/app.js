// Modulo 3 - Semana 2
console.log("¡Bienvenido a la Gestión de Datos con Objetos, Sets y Maps!")

// Nota: Lo quise hacer interactivo para poder aplicar los conocimientos de la semana anterior
// Lista de productos en un Objeto (Para definir los productos):
let itemsObject = [];

// Lista de productos en un Set (Para que no haya repetidos [Sin incluir la categoria.]):
const itemsSet = new Set();

function OnlyBigInt(text) {
    return /^[A-Za-zÁÉÍÓÚÑáéíóúñ0123456789\s]+$/.test(text);  
}

// Limite de itemsObject:
for (let list = 1; list <= 3;) { // IMPORTANTE: No aumenta, hasta que el producto sea valido.

    // Definición y validación de nombre:
    let name = prompt(`Ingrese el nombre del producto ${list}:`).trim();
    while (!OnlyBigInt(name)) { //Permití que se pudiera números en los nombres porque existen productos que pueden tener números en el nombre.
    alert("Error: Ingresa solo letras en nombre o números.");
    name = prompt(`Ingrese el nombre del producto ${list}:`).trim(); 
}

// Definición y validación de precio:
    let price;
    while (true) {
        let input = prompt(`Ingrese el precio del producto ${list}:`).trim();

        // Si no ingresa nada, se establece en cero:
        if (input === "") {
        console.log("Precio invalido. Se establecerá en cero.")
        price = 0;
        break;
    };
    
    // Conversión a decimal y redondeando el precio a 2 decimales:
    price = parseFloat(input);
    price = parseFloat(price.toFixed(2));

    // Validadición de que el precio no sea negativo:
    if (!isNaN(price) && price >= 0) {
        break;
    } else {
        alert("Precio invalido, ingresa un número valido positivo.")
    }
}

    // Definición  y validación de categoria (Para Map):
    let category = prompt(`¿A que categoria pertenece su producto?`).trim();
    while (!OnlyBigInt(category)) {
    alert("Error: Ingresa solo letras o números.");
    category = prompt(`¿A que categoria pertenece su producto?`).trim();   
}

    // Como se van a guardar los productos:
    let product = {
        id: list,
        name: name,
        price: price,
        category: category,
    };

    // Crear clave única para el Set (nombre + precio):
    let uniqueKey = `${name.toLowerCase()} - $${price}`; // Agregue el metodo .toLowerCase en caso de que se quiera confundir el sistema entre minusculas y mayusculas.
    if (itemsSet.has(uniqueKey)) {
        alert("Ese producto (nombre y precio) ya fue registrado. Ingresa uno diferente.");
        continue; // No incrementa 'list', vuelve a pedir datos.
    }

    // Si no está repetido, lo agregamos:
    itemsSet.add(uniqueKey);


    // Agregar cada producto dentro de la lista:
    itemsObject.push(product);
    list++;
};

// Impresión de la lista de productos.
console.log("Productos Registrados:");
for (let products of itemsObject) {
    console.log(`Producto con ID registrado: ${products.id} - Nombre: ${products.name} - Precio: ${products.price} - Categoria: ${products.category}.`);
};


// Lista de productos en un Map (Para agregar categorias):
const itemsMap = new Map();
for (let product of itemsObject) {
    itemsMap.set(product.category, product.name);
};


// Impresiones con for:
// Objeto:
console.warn("Impresión de Objeto")
for (const id in itemsObject) {
    console.log(`Producto ID: ${id.toLowerCase()}, Detalles:`, itemsObject[id.toLowerCase()]);
};

// Set:
console.warn("Impresión de Set")
for (const product of itemsSet) {
    console.log("Producto único:", product.toLowerCase());
};

// Map:
console.warn("Impresión de Map")
itemsMap.forEach((product, category) => {
    console.log(`Categoría: ${category.toLowerCase()}, Producto: ${product.toLowerCase()}`);
});